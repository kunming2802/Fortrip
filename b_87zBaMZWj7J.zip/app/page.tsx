import { TripManager } from '@/components/trip-manager'

export default function Home() {
  return <TripManager />
}
